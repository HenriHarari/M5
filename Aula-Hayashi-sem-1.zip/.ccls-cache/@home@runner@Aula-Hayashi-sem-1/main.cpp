// CPP program to illustrate substr()
#include <string.h>
#include <iostream>
using namespace std;
 
int main()
{
    // Take any string
    string s1 = "ab688fa874a10811a914e579b97c9f976b73bfb02792a25fb97b9f7c1fc66c92";
 
    // Copy two characters of s1 (starting
    // from position 3)
    string r = s1.substr(2, 6);
 
    // prints the result
    cout << "String is: " << r;
 
    return 0;
}