//A classe possui dois atributos privados: IMEI e login, que são do tipo inteiro e string, respectivamente. A classe tem dois construtores: um construtor padrão e outro que permite a inicialização dos atributos IMEI e login. Além disso, há duas funções públicas, getLogin() e getIMEI(), que retornam os valores dos atributos IMEI e login, respectivamente. Observe que o código inclui o header "iostream" e usa o namespace "std". Isso permite que a classe use funções como cout e endl da biblioteca iostream.A classe está bem estruturada e de acordo com boas práticas de programação em C++. No entanto, é recomendável adicionar a palavra-chave "const" ao final de cada função get, pois essas funções não modificam os atributos da classe.
#include <iostream>
using namespace std;
class Cliente{
private :
  int         IMEI;
  std::string login;
public:
  Cliente();
  Cliente(int IMEI, std::string login);
  string getLogin() const;
  int getIMEI() const;
};