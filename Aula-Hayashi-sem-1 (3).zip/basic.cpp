//. A classe Hash tem dois construtores, um que permite especificar o tamanho máximo da tabela hash e outro padrão sem argumentos.A classe tem métodos para inserir, excluir e recuperar itens da tabela hash, bem como um método para imprimir o conteúdo da tabela. Além disso, há um método para verificar se a tabela hash está cheia e outro para retornar o tamanho da tabela. O método getHash é usado para calcular a posição na tabela hash para um objeto Cliente específico. Isso é feito retornando o resto da divisão do IMEI do cliente pelo tamanho máximo da tabela hash. Ao destruir a classe, é importante liberar a memória alocada para a estrutura da tabela hash com o operador delete
#include "hash.h"
#include <iostream>
using namespace std;
Hash::Hash(int max) {
  length = 0;
  max_items = max;
  structure = new Cliente[max_items];
}
Hash::Hash(){
  delete [] structure;
}
bool Hash::isFull() const {
  return (length == max_items);
}
int Hash::getLength() const {
  return length;
}
void Hash::retrieveItem(Cliente& cliente, bool& found) {
  int location = getHash(cliente);
  Cliente aux    = structure[location];
  if (cliente.getIMEI() != aux.getIMEI()) {
    found      = false;
  } else {
    found      = true;
    cliente      = aux;
  }
}
void Hash::insertItem(Cliente cliente) {
  int location = getHash(cliente);
  structure[location] = cliente;
  length++;
}
void Hash::deleteItem(Cliente cliente) {
  int location = getHash(cliente);
  structure[location] = Cliente();
  length--;
}
void Hash::print() {
  for (int i = 0; i < max_items; i++) {
    cout << i <<":"<<
      structure[i].getIMEI()<<", "<<
      structure[i].getLogin()<<endl;
  }
}
int Hash::getHash(Cliente cliente){
  return cliente.getIMEI() % max_items;
}
