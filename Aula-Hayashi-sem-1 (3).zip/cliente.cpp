//A classe possui dois construtores: um construtor padrão e outro que permite a inicialização dos atributos IMEI e login. Além disso, há duas funções get, getLogin() e getIMEI(), que retornam os valores dos atributos.A classe também inclui o header "cliente.h", que provavelmente define a declaração da classe Cliente.A classe é bem estruturada, mas há algumas melhorias que poderiam ser feitas. Por exemplo, o construtor padrão pode ser removido e os valores iniciais dos atributos podem ser definidos no construtor com argumentos, já que ambos são obrigatórios. Além disso, é recomendável adicionar a palavra-chave "const" ao final de cada função get, pois essas funções não modificam os atributos da classe.
#include "cliente.h"
Cliente::Cliente(){
  this->IMEI   = -1;
  this->login = "";
};
Cliente::Cliente(int IMEI, std::string login){
  this->IMEI    = IMEI;
  this->login  = login;
}
string Cliente::getLogin() const {
  return login;
}
int Cliente::getIMEI() const{
  return IMEI;
}

