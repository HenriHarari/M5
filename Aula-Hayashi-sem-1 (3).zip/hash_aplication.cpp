#include <iostream>
#include "hash.h"
using namespace std;
int main(){
  Hash clientesHash(10);
   int   ras[7]   = {
     12704, 31300, 1234,
     49001, 52202, 65606,
     91234};
  string login[7] = {
    "Dudu", "Weverton", "Veiga",
    "Danilo", "Gomez", "Murilo",
    "Piquerez"};
	   
  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i], login[i]);
    clientesHash.insertItem(cliente);
  }
  clientesHash.print();
  cout << "------------------------------" <<  endl;
  Cliente cliente(12704,"");
  bool     found = false;
  clientesHash.retrieveItem(cliente, found);
  cout << cliente.getLogin() << " -> " << found << endl;
  cout << "------------------------------" <<  endl;
  clientesHash.deleteItem(cliente);
  clientesHash.print();
  cout << "Fim" << endl;
}
//Casos de teste:
 //Teste de inserção dos clientes
void test_insertItem() {
  Hash clientesHash(10);
  int ras[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string login[7] = {"Dudu", "Weverton", "Veiga", "Danilo", "Gomez", "Murilo", "Piquerez"};

  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i], login[i]);
    clientesHash.insertItem(cliente);
  }
  assert(clientesHash.getNumOfItems() == 7);
}


//Teste de busca de um cliente
void test_retrieveItem() {
  Hash clientesHash(10);
  int ras[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string login[7] = {"Dudu", "Weverton", "Veiga", "Danilo", "Gomez", "Murilo", "Piquerez"};

  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i], login[i]);
    clientesHash.insertItem(cliente);
  }

  Cliente cliente(12704,"");
  bool found = false;
  clientesHash.retrieveItem(cliente, found);

  assert(found == true);
  assert(cliente.getLogin() == "Dudu");
}

//Teste de exclusão de um cliente:
void test_deleteItem() {
  Hash clientesHash(10);
  int ras[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string login[7] = {"Dudu", "Weverton", "Veiga", "Danilo", "Gomez", "Murilo", "Piquerez"};

  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i], login[i]);
    clientesHash.insertItem(cliente);
  }
{
  Cliente cliente(12704,"");
  clientesHash.deleteItem(cliente);
  }
  {
  bool found = false;
  clientesHash.retrieveItem(cliente, found);
    
  assert(found == false);
}

//Teste de colisão:
void test_collision() {
  Hash clientesHash(2);
  int ras[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string login[7] = {"Dudu", "Weverton", "Veiga", "Danilo", "Gomez", "Murilo", "Piquerez"};

  for (int i = 0; i < 7; i++) {
    Cliente cliente = Cliente(ras[i}
